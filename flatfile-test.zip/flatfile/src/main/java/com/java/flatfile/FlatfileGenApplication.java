package com.java.flatfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlatfileGenApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlatfileGenApplication.class, args);
	}

}
