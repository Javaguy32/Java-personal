package com.java.flatfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlatfileGenApplicationTests {

	@Test
	void contextLoads() {
	}

}
